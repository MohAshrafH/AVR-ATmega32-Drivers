/*
 * LM35_private.h
 *
 *  Created on: Nov 10, 2023
 *      Author: elara
 */

#ifndef HAL_LM35_LM35_PRIVATE_H_
#define HAL_LM35_LM35_PRIVATE_H_



#endif /* HAL_LM35_LM35_PRIVATE_H_ */
