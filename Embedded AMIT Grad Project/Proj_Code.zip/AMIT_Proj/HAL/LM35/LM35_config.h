/*
 * LM35_config.h
 *
 *  Created on: Nov 10, 2023
 *      Author: elara
 */

#ifndef HAL_LM35_LM35_CONFIG_H_
#define HAL_LM35_LM35_CONFIG_H_



#endif /* HAL_LM35_LM35_CONFIG_H_ */
