/*
 * ADC_interface.h
 *
 *  Created on: Nov 10, 2023
 *      Author: elara
 */

#ifndef MCAL_ADC_ADC_INTERFACE_H_
#define MCAL_ADC_ADC_INTERFACE_H_

void ADC_voidInit(void);
u16 ADC_u16Read(u8 Copy_u8Channel);


#endif /* MCAL_ADC_ADC_INTERFACE_H_ */
