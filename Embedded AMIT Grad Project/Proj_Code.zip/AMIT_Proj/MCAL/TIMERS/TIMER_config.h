/*
 * TIMER_config.h
 *
 *  Created on: Nov 8, 2023
 *      Author: elara
 */

#ifndef MCAL_TIMERS_TIMER_CONFIG_H_
#define MCAL_TIMERS_TIMER_CONFIG_H_



#endif /* MCAL_TIMERS_TIMER_CONFIG_H_ */
